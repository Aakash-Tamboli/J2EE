package bobby.test;
import com.thinking.machines.webrock.annotations.*;


@Path("/university")
public class University 
{
public void courses()
{
// later on
}
}
