package bobby.test;
import com.thinking.machines.webrock.annotations.*;
import com.thinking.machines.webrock.scope.*;


@Path("/university")
public class University 
{
@AutoWired(name="Aakash") //it means AutoWired that Student Object which is created by College Class 
private Student student1;

@AutoWired(name="Bittu") //it means AutoWired that Student Object which is created by College Class 
private Student student2;

@Path("/studentDetail")
@Forward("/Aakash.jsp")
public void courses()
{
System.out.println("*****************JUST TO VISIBLE ON CONSOLE**********************");
System.out.println("Courses Method called by TMWebRock Framework of University Class");
if(student1!=null) System.out.println("Student Name: "+this.student1.getName());
if(student2!=null) System.out.println("Student Name: "+this.student2.getName());
System.out.println("*****************JUST TO VISIBLE ON CONSOLE**********************");
}
}
