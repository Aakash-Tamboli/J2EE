package bobby.test;
import com.thinking.machines.webrock.scope.*;
import com.thinking.machines.webrock.annotations.*;


@InjectSessionScope
@Path("/college")
public class College
{
private SessionScope sessionScope;
public void setSessionScope(SessionScope sessionScope)
{
this.sessionScope=sessionScope;
}

@Path("/addStudent")
@Forward("/Student.jsp")
public void addStudent()
{
Student student=new Student();
student.setName("Aakash");
sessionScope.setAttribute("Aakash",student);
student=new Student();
student.setName("Bittu");
sessionScope.setAttribute("Bittu",student);
}
}
