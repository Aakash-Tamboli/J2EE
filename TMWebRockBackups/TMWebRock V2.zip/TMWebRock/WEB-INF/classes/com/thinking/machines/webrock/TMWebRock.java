package com.thinking.machines.webrock;
import javax.servlet.*;
import javax.servlet.http.*;
import java.lang.reflect.*;
import com.thinking.machines.webrock.annotations.*;
import com.thinking.machines.webrock.model.*;
import com.thinking.machines.webrock.pojo.*;



public class TMWebRock extends HttpServlet
{
private ServletContext servletContext;
private WebRockModel model;

public void init(ServletConfig servletConfig) throws ServletException
{
this.servletContext=servletConfig.getServletContext();
this.model=(WebRockModel)this.servletContext.getAttribute("dataStructure");
}

public void doGet(HttpServletRequest request,HttpServletResponse response)
{
try
{
System.out.println("DEBUG: "+request.getContextPath());
System.out.println("DEBUG: "+request.getPathInfo());
System.out.println("DEBUG: model size: "+model.dataStructure.size());

String key=request.getPathInfo();
String serviceURL=key.substring(key.indexOf("/",1));
System.out.println("Service URL: "+serviceURL);


if(model.dataStructure.containsKey(key))
{
System.out.println("God is Great key is there");
Service mainService=model.dataStructure.get(key);
String anotherServiceURL=mainService.getPath().substring(key.indexOf("/",1));
System.out.println("Another Service URL: "+anotherServiceURL);
System.out.println("[doGet] RequestType Value: "+mainService.getRequestType());

if((mainService.getRequestType()==1 || mainService.getRequestType()==3) && serviceURL.equalsIgnoreCase(anotherServiceURL) )
{
// 1 means it is specify by bobby, that subService should be done at GET type.
// 3 means it is specify by bobby, that subService should be done at any type of request.
Method subService=mainService.getService();
subService.invoke(mainService.getServiceClass().newInstance());
// here forward related code
if(mainService.getForwardTo()!=null && mainService.getForwardTo().length()>0)
{
RequestDispatcher requestDispatcher;
System.out.println("Forwarding: "+request.getServletPath()+key.substring(0,key.indexOf("/",1))+mainService.getForwardTo());
requestDispatcher=request.getRequestDispatcher(request.getServletPath()+key.substring(0,key.indexOf("/",1))+mainService.getForwardTo());
requestDispatcher.forward(request,response);
}
}
else
{
if(serviceURL.equalsIgnoreCase(anotherServiceURL)==false) response.sendError(HttpServletResponse.SC_FOUND);
else response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
}
}
else
{
RequestDispatcher requestDispatcher;
requestDispatcher=request.getRequestDispatcher(serviceURL);
requestDispatcher.forward(request,response);
}
}catch(Exception exception)
{
System.out.println("Exception got raised");
System.out.println(exception);
}
} // doGet ends

public void doPost(HttpServletRequest request,HttpServletResponse response)
{
try
{
System.out.println("DEBUG: "+request.getContextPath());
System.out.println("DEBUG: "+request.getPathInfo());
System.out.println("DEBUG: model size: "+model.dataStructure.size());

String key=request.getPathInfo();
String serviceURL=key.substring(key.indexOf("/",1));
System.out.println("Service URL: "+serviceURL);

if(model.dataStructure.containsKey(key))
{
System.out.println("God is Great key is there");
Service mainService=model.dataStructure.get(key);
String anotherServiceURL=mainService.getPath().substring(key.indexOf("/",1));
System.out.println("Another Service URL: "+anotherServiceURL);
System.out.println("[doPost]RequestType value: "+mainService.getRequestType());
if((mainService.getRequestType()==2 || mainService.getRequestType()==3) && serviceURL.equalsIgnoreCase(anotherServiceURL) )
{
// 2 means it is specify by bobby, that subService should be done at POST type.
// 3 means it is specify by bobby, that subService should be done at any type of request.
System.out.println("Service is in action");
Method subService=mainService.getService();
subService.invoke(mainService.getServiceClass().newInstance());
// here forward related code

if(mainService.getForwardTo()!=null && mainService.getForwardTo().length()>0)
{
RequestDispatcher requestDispatcher;
System.out.println("Forwarding: "+request.getServletPath()+key.substring(0,key.indexOf("/",1))+mainService.getForwardTo());
requestDispatcher=request.getRequestDispatcher(request.getServletPath()+key.substring(0,key.indexOf("/",1))+mainService.getForwardTo());
requestDispatcher.forward(request,response);
}

}
else
{
if(serviceURL.equalsIgnoreCase(anotherServiceURL)==false) response.sendError(HttpServletResponse.SC_FOUND);
else response.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
}
}
else
{
RequestDispatcher requestDispatcher;
requestDispatcher=request.getRequestDispatcher(serviceURL);
requestDispatcher.forward(request,response);
}
}catch(Exception exception)
{
System.out.println("Exception got raised");
System.out.println(exception);
}
} // doPost ends
} // class ends
