package com.thinking.machines.webrock.pojo;
import java.lang.reflect.*;

public class Service
{
/*
if at class level @GET means 1
if at class level @POST means 2
if at class level niether @GET nor POST then I look into inside class
if class's method have @GET means 1
if class's method have @POST means 2
if class's method only @PATH means 3
3 means below defined method can be access in any type.

if class level have @GET and inside class have different annotation
then class level takes priority and all the class method only can be
access through GET type request.
*/
private byte requestType;
private Class serviceClass;
private String path;
private String forwardTo;
private Method service;
// Sir say "It will be more in future so mentally prepared"
// constructor starts
public Service()
{
this.requestType=3;
this.serviceClass=null;
this.path="";
this.forwardTo=null;
this.service=null;
}
public Service(byte requestType,Class serviceClass,String path,String forwardTo,Method service)
{
this.requestType=requestType;
this.serviceClass=serviceClass;
this.path=path;
this.forwardTo=forwardTo;
this.service=service;
}
// constructor ends
// setter starts
public void setRequestType(byte requestType)
{
this.requestType=requestType;
}
public void setServiceClass(Class serviceClass)
{
this.serviceClass=serviceClass;
}
public void setPath(String path)
{
this.path=path;
}
public void setForwardTo(String forwardTo)
{
this.forwardTo=forwardTo;
}
public void setService(Method method)
{
this.service=service;
}
// setter ends
// getter starts
public byte getRequestType()
{
return this.requestType;
}
public Class getServiceClass()
{
return this.serviceClass;
}
public String getPath()
{
return this.path;
}
public String getForwardTo()
{
return this.forwardTo;
}
public Method getService()
{
return this.service;
}
// getter ends
}
