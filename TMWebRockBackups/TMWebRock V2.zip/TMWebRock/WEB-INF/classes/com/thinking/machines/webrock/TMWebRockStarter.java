package com.thinking.machines.webrock;
import javax.servlet.*;
import javax.servlet.http.*;
import com.thinking.machines.webrock.model.*;
import com.thinking.machines.webrock.annotations.*;
import com.thinking.machines.webrock.pojo.*;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

public class TMWebRockStarter extends HttpServlet
{
public void init(ServletConfig servletConfig) throws ServletException
{
System.out.println("\n\n\n\t\t\t\t TMWebRockStarter is in action \n\n\n\n");
String prefix=servletConfig.getInitParameter("SERVICE_PACKAGE_PREFIX");
System.out.println("["+prefix+"]\n");
WebRockModel model=new WebRockModel();

/*
System.getProperty("cataline.base"); // resource from https://stackoverflow.com/questions/48748318/how-to-get-the-path-upto-webapps-folder-of-tomcat-in-servlet#:~:text=1%20Answer&text=String%20webApp%20%3D%20String.,the%20path%20will%20always%20work.
*/

String knownFact=System.getProperty("catalina.base")+File.separator+"webapps"+File.separator+"TMWebRock"+File.separator+"WEB-INF"+File.separator+"classes"+File.separator+prefix;
File file=new File(knownFact);
Stack<File> stack=new Stack<>();
List<String> list=new ArrayList<>();
stack.push(file);
String str="";
File[] f;
while(!stack.empty())
{
file=stack.pop();
if(file.isFile())
{
str=file.getName();
if(str.substring(str.length()-6).equals(".class"))
{
str=file.getAbsolutePath().replaceAll(File.separator,".");
str=str.substring(str.indexOf(prefix));
str=str.substring(0,str.length()-6);
list.add(str);
}
}
else if(file.isDirectory())
{
f=file.listFiles();
for(File f1: f) stack.push(f1);
}
}// loop ends

Class c;
Path path;
Forward forward;
String str2="";
byte requestType;
String forwardTo=null;


for(String classes: list)
{
try
{
c=Class.forName(classes);
if(c.isAnnotationPresent(Path.class))
{
path=(Path)c.getAnnotation(Path.class);
str=path.value();
if(str.length()==0) continue;
if(c.isAnnotationPresent(GET.class)) requestType=1;
else if(c.isAnnotationPresent(POST.class)) requestType=2;
else requestType=3;

for(Method m: c.getDeclaredMethods())
{
if(m.isAnnotationPresent(Path.class))
{
path=m.getAnnotation(Path.class);
str2=path.value();
if(str2.length()==0) continue;
if(c.isAnnotationPresent(GET.class)==false && c.isAnnotationPresent(POST.class)==false) // it means class level does not have niether @GET nor @POST so I have to check on method level
{
if(m.isAnnotationPresent(GET.class)) requestType=1;
else if(m.isAnnotationPresent(POST.class)) requestType=2;
else requestType=3;
}
if(m.isAnnotationPresent(Forward.class))
{
forward=m.getAnnotation(Forward.class);
forwardTo=forward.value();
if(forwardTo.length()==0) forwardTo=null;
}
System.out.println("Service Object created with requestType: "+requestType+" Class,Path="+str+str2+" forwardTo:"+forwardTo+" ,Method");
model.dataStructure.put(str+str2,new Service(requestType,c,str+str2,forwardTo,m));
forwardTo=null; // for next cycle
}
}// inner loop ends
}
}catch(ClassNotFoundException cnfe)
{
System.out.println("Problem");
}
}
ServletContext servletContext=servletConfig.getServletContext(); //https://www.javatpoint.com/servletcontext
servletContext.setAttribute("dataStructure",model);
}
}
