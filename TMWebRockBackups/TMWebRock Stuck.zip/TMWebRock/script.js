class Student{
constructor(rollNumber,name,gender){
this.rollNumber=rollNumber;
this.name=name;
this.gender=gender;
}
setRollNumber(rollNumber){
this.rollNumber=rollNumber;
}
setName(name){
this.name=name;
}
setGender(gender){
this.gender=gender;
}
}
