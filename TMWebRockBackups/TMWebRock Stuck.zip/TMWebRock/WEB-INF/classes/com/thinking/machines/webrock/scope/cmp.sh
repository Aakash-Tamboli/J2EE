javac -classpath /opt/tomcat/lib/*:. *.java
