import java.io.*;
class psp
{
public static void main(String []args) throws Exception
{
File file=new File("/opt/tomcat/webapps/TMWebRock/WEB-INF/js");
if(file.exists()==false)
{
try
{
Process process=Runtime.getRuntime().exec("sudo mkdir /opt/tomcat/webapps/TMWebRock/WEB-INF/js");
process.waitFor();
System.out.println("Directory created");
process.destroy();
}catch(Exception exception)
{
System.out.println(exception);
}

}
}
}
