javac -classpath /opt/tomcat/webapps/TMWebRock/WEB-INF/classes:/opt/tomcat/webapps/TMWebRock/WEB-INF/lib/*. *.java
