package bobby.test;

import com.thinking.machines.webrock.annotations.*;

@Path("/hospital")
public class Medical
{
// later on
@Path("/medecineTime")
void giveMeds()
{
// later on
}
@Path("/doc")
void callDoctor()
{
// later on
}
}
