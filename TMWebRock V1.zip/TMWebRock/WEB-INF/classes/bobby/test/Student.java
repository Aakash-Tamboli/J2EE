package bobby.test;
import com.thinking.machines.webrock.annotations.*;

@Path("/student")
public class Student 
{
@Path("/add")
void add()
{
// later on
}
// later on
}
