package com.thinking.machines.webrock.pojo;
import java.lang.reflect.*;

public class Service
{
private Class serviceClass;
private String path;
private Method service;
// Sir say "It will be more in future so mentally prepared"
// constructor starts
public Service()
{
this.serviceClass=null;
this.path="";
this.service=null;
}
public Service(Class serviceClass,String path,Method service)
{
this.serviceClass=serviceClass;
this.path=path;
this.service=service;
}
// constructor ends
// setter starts
public void setServiceClass(Class serviceClass)
{
this.serviceClass=serviceClass;
}
public void setPath(String path)
{
this.path=path;
}
public void setService(Method method)
{
this.service=service;
}
// setter ends
// getter starts
public Class getServiceClass()
{
return this.serviceClass;
}
public String getPath()
{
return this.path;
}
public Method getService()
{
return this.service;
}
// getter ends
}
