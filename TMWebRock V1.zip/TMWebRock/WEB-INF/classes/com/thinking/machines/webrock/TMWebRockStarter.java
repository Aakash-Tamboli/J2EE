package com.thinking.machines.webrock;
import javax.servlet.*;
import javax.servlet.http.*;
import com.thinking.machines.webrock.model.*;
import com.thinking.machines.webrock.annotations.*;
import com.thinking.machines.webrock.pojo.*;
import java.lang.reflect.*;
import java.io.*;
import java.util.*;

public class TMWebRockStarter extends HttpServlet
{
public void init(ServletConfig servletConfig) throws ServletException
{
System.out.println("\n\n\n\t\t\t\t TMWebRockStarter is in action \n\n\n\n");
String prefix=servletConfig.getInitParameter("SERVICE_PACKAGE_PREFIX");
System.out.println("["+prefix+"]\n");
WebRockModel model=new WebRockModel();

/*
System.getProperty("cataline.base"); // resource from https://stackoverflow.com/questions/48748318/how-to-get-the-path-upto-webapps-folder-of-tomcat-in-servlet#:~:text=1%20Answer&text=String%20webApp%20%3D%20String.,the%20path%20will%20always%20work.
*/

String knownFact=System.getProperty("catalina.base")+File.separator+"webapps"+File.separator+"TMWebRock"+File.separator+"WEB-INF"+File.separator+"classes"+File.separator+prefix;
File file=new File(knownFact);
Stack<File> stack=new Stack<>();
List<String> list=new ArrayList<>();
stack.push(file);
String str="";
File[] f;
while(!stack.empty())
{
file=stack.pop();
if(file.isFile())
{
str=file.getName();
if(str.substring(str.length()-6).equals(".class"))
{
str=file.getAbsolutePath().replaceAll(File.separator,".");
str=str.substring(str.indexOf(prefix));
str=str.substring(0,str.length()-6);
list.add(str);
}
}
else if(file.isDirectory())
{
f=file.listFiles();
for(File f1: f) stack.push(f1);
}
}// loop ends

Class c;
Path path;
String str2="";

for(String classes: list)
{
try
{
c=Class.forName(classes);
if(c.isAnnotationPresent(Path.class))
{
path=(Path)c.getAnnotation(Path.class);
str=path.value();
for(Method m: c.getDeclaredMethods())
{
if(m.isAnnotationPresent(Path.class))
{
path=m.getAnnotation(Path.class);
str2=path.value();
System.out.println("Service Object created with Class,Path="+str+str2+",Method");
model.dataStructure.put(str+str2,new Service(c,str+str2,m));
}
}// inner loop ends
}
}catch(ClassNotFoundException cnfe)
{
System.out.println("Problem");
}
}

ServletContext servletContext=getServletContext();
servletContext.setAttribute("dataStructure",model);


}
}
