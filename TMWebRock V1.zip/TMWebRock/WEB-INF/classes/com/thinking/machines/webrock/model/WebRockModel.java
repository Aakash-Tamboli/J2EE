package com.thinking.machines.webrock.model;
import java.util.*;
import com.thinking.machines.webrock.pojo.*;

public class WebRockModel
{
public Map<String,Service> dataStructure=new HashMap<>();
}
