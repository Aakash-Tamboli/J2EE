javac -classpath /opt/tomcat/lib/*:/opt/tomcat/webapps/TMWebRock/WEB-INF/classes:. *.java
