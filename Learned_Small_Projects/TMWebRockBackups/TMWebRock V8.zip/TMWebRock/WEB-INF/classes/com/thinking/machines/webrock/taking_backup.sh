cp -r * ../bck/
